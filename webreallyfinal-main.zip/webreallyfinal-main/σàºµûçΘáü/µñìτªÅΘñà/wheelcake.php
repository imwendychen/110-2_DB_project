<!DOCTYPE html>
<html>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

<head>
    <title>植福餅</title>
    <!-- 字體 -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=EB+Garamond&family=Noto+Serif+TC:wght@500&family=PT+Serif&family=Vollkorn&display=swap" rel="stylesheet">
    <!-- bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous" />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <!-- css js -->
    <link href="../../menunav.css" rel="stylesheet" />
    <link href="wheel.css" rel="stylesheet" />
    <link rel="stylesheet" href="wheel_screen.css" />
    <link rel="stylesheet" href="../rating.css" />
    <script src="../../common.js"></script>
    <link rel="icon" type="image/x-icon" href="../../common img/titleicon.png" />
    <!-- font awesome -->
    <script defer src="https://use.fontawesome.com/releases/v5.0.10/js/all.js" integrity="sha384-slN8GvtUJGnv6ca26v8EzVaR9DC58QEwsIk9q1QXdCU8Yu8ck/tL/5szYlBbqmS+" crossorigin="anonymous"></script>
</head>

<body id="body">
    <header>
        <nav class="navbarr navbar-light bg-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="../../主頁/yanchengtour.php">
                    <img src="../../common img/titleicon.png" alt="" width="65" height="65" class="d-inline-block align-text-top" />
                    <div id="brandname">Hola Foodie</div>
                </a>
                <button id="mobile-menu">
                    <img src="../../common img/more.png" alt="" class="menuicon" />
                </button>
                <form action="/action.php" id="form">
                    <a href="../../搜尋/index.php">
                        <label for="searchblank" id="search"><img src="../../common img/magnifier.png" id="magnifier"></label>
                        <input type="text" id="searchkey" name="searchblank">
                    </a>
                </form>
            </div>
        </nav>
        <ul class="nav">
            <li class="nav-item">
                <a class="nav-link" href="../../主頁/yanchengtour.php">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../../post/phase2.php">Posts</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../關於我們/aboutus.php">About Us</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../../登入/index.php">Member Area</a>
            </li>
        </ul>
        <div id="mobilenavbar">
            <div class="mobilenav-item">
                <a class="mnav-link" href="../../主頁/yanchengtour.php">Home</a>
            </div>
            <div class="mobilenav-item">
                <a class="mnav-link" href="../../post/phase2.php">Posts</a>
            </div>
            <div class="mobilenav-item">
                <a class="mnav-link" href="../關於我們/aboutus.php">About Us</a>
            </div>
            <div class="mobilenav-item">
                <a class="mnav-link" href="../../登入/index.php">Member Area</a>
            </div>
        </div>
    </header>
    <div class="Title">
        <div class="content">
            植福餅
            <br />不只是vegan的福音，葷食者也會愛上的車輪餅
        </div>
    </div>
    <main>
        <div class="article" id="article">
            <div class="rating">
                <form method="POST">
                    <a class="rating" href="../評分系統/index.php?Post_Id=5">新增評分</a>
                </form>
            </div>
            <br><br>
            <form method="POST" action="../評分系統/saved.php?Post_Id=5"  class="">
                <button><img title="快來收藏文章吧" src="../../common img/save-instagram.png" width="35px"></button>
            </form>
            <div class="articalTitle">
                多種口味的全素車輪餅實屬難得一見
            </div>
            <div class="lines">
                <span class="line1"></span>
                <span id="font">19th&nbsp;December&nbsp;2021</span>
                <span class="line2"></span>
            </div>
            <div class="imageSquare">
                <img src="img/image2.jpg" alt="" class="topimage" />
                <div class="topcontent">
                    全素的車輪餅還是第一次吃。
                    <br>這間一直在小編的口袋名單很久了，
                    <br>不管是IG YT都超多人推薦這間，價格雖然偏高🥲
                    <br>不過我覺得非常值這個價格喔🤍
                    <br>車輪餅的餅皮跟以往吃到的不太一樣，我大多吃的是偏軟，這間的餅皮香薄又脆口。
                    <br>雖然我不是個素食者，但是這間我還是很推！！！下次還要去試試其它口味😋
                </div>
            </div>
            <div class="imageSquare">
                <div class="smalltitle">🔅三杯基總匯$30/顆</div>
                <div class="decorate"></div>
                <div class="topcontent">
                    雖然猜不到仿雞肉的食材是什麼做的，不過三杯味好正點！！底層鋪的是馬鈴薯泥，整體口味很新奇，不過也很好吃😋
                </div>
            </div>
            <div class="imageSquare">
                <div class="smalltitle">🔅餅乾巧克力 $25/顆</div>
                <div class="decorate"></div>
                <div class="topcontent">
                    上面的cream字樣起初以為是烙印上去的，想說也太多模了吧（好用心），後來才發現其實就是餅乾啦😅巧克力甜度不高，
                    <br>而且是融化狀態，餅乾甜度較高，配在一起蠻和諧的！
                </div>
            </div>
            <div class="time">
                📍 植福餅Wheels Of Fortune
                <br>營業時間 :12:00-18:00(週日公休）
                <br>電話：0971-819-276
                <br>地址：801高雄市前金區六合二路129號
            </div>
            <div class="uber">
                <a href="https://m.uber.com/looking?drop%5B0%5D=%7B%22latitude%22%3A22.6311517%2C%22longitude%22%3A120.2967464%2C%22addressLine1%22%3A%22%E6%A4%8D%E7%A6%8F%E9%A4%85%20Wheels%20of%20Fortune%22%2C%22addressLine2%22%3A%22%E5%8F%B0%E6%B9%BE%E9%AB%98%E9%9B%84%E5%B8%82%E5%89%8D%E9%87%91%E5%8C%BA%E5%85%AD%E5%90%88%E4%BA%8C%E8%B7%AF%22%2C%22id%22%3A%22ChIJZ6ntj-oFbjQRI7q2OfT_1sE%22%2C%22provider%22%3A%22google_places%22%7D" target="_blank"><img src="../../common img/uber.png" id="bookingimg" alt="" width="60" height="60" /></a>
                <a href="../../booking/booking/booking.html" target="_blank"><img src="../../common img/booking.png" id="bookingimg" alt="" width="60" height="60" /></a>
            </div>
        </div>
    </main>
    <footer>
        <div class="footerSquare">
            <a href="#body">
                <div id="back"><i class="fas fa-angle-double-up"></i> Go to Top</div>
            </a>
            <div class="contactus">CONTACT US</div>
            <div id="igiconii">
                <div id="igicondiv">
                    <a href="https://www.instagram.com/hola._.foodie/" target="_blank"><img src="../../common img/igicon.png" alt="" class="igicon" /></a>
                </div>
            </div>
            <div class="footercontent">
                <p>TEL:07-5252000</p>
                <p>EMAIL:holafoodie@gmail.com</p>
                <p>ADDRESS:No.70,Lianhai Rd, Gushan District, Kaohsiung City,804</p>
                <p>SERVICE HOUR:09:00~17:00</p>
                <p id="copyright">© 2021 Hola.foodie all rights reserved</p>
            </div>
        </div>
    </footer>
</body>

</html>