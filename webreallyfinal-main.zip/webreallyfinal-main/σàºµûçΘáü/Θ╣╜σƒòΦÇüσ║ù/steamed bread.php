<!DOCTYPE html>
<html>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

<head>
    <title>鹽埕老店</title>
    <!-- 字體 -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=EB+Garamond&family=Noto+Serif+TC:wght@500&family=PT+Serif&family=Vollkorn&display=swap" rel="stylesheet">
    <!-- bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous" />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <!-- css js -->
    <link href="../../menunav.css" rel="stylesheet" />
    <link href="bread.css" rel="stylesheet" />
    <link rel="stylesheet" href="bread_screen.css" />
    <link rel="stylesheet" href="../rating.css" />
    <script src="../../common.js"></script>
    <link rel="icon" type="image/x-icon" href="../../common img/titleicon.png" />
</head>

<body id="body">
    <header>
        <nav class="navbarr navbar-light bg-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="../../主頁/yanchengtour.php">
                    <img src="../../common img/titleicon.png" alt="" width="65" height="65" class="d-inline-block align-text-top" />
                    <div id="brandname">Hola Foodie</div>
                </a>
                <button id="mobile-menu">
                    <img src="../../common img/more.png" alt="" class="menuicon" />
                </button>
                <form action="/action.php" id="form">
                    <a href="../../搜尋/index.php">
                        <label for="searchblank" id="search"><img src="../../common img/magnifier.png" id="magnifier"></label>
                        <input type="text" id="searchkey" name="searchblank">
                    </a>
                </form>
            </div>
        </nav>
        <ul class="nav">
            <li class="nav-item">
                <a class="nav-link" href="../../主頁/yanchengtour.php">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../../post/phase2.php">Posts</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../關於我們/aboutus.php">About Us</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../../登入/index.php">Member Area</a>
            </li>
        </ul>
        <div id="mobilenavbar">
            <div class="mobilenav-item">
                <a class="mnav-link" href="../../主頁/yanchengtour.php">Home</a>
            </div>
            <div class="mobilenav-item">
                <a class="mnav-link" href="../../post/phase2.php">Posts</a>
            </div>
            <div class="mobilenav-item">
                <a class="mnav-link" href="../關於我們/aboutus.php">About Us</a>
            </div>
            <div class="mobilenav-item">
                <a class="mnav-link" href="../../登入/index.php">Member Area</a>
            </div>
        </div>
    </header>
    <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-indicators">
            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
        </div>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="img/title1.jpg" class="d-block w-100" alt="..." />
            </div>
            <div class="carousel-item">
                <img src="img/title2.jpg" class="d-block w-100" alt="..." />
            </div>
            <div class="carousel-item">
                <img src="img/title3.jpg" class="d-block w-100" alt="..." />
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>
    <main>
        <!--永青饅頭-->
        <div class="article" id="article">
            <div class="rating">
                <form method="POST">
                    <a class="rating" href="../評分系統/index.php?Post_Id=1">新增評分</a>
                </form>
            </div>
            <div class="articalTitle">
                漫步於街道早晨 思索著慢慢耕耘為何物? 瞞不住也猜不透 我想...這就是所謂饅頭"內涵"吧!
            </div>
            <div class="lines">
                <span class="line1"></span>
                <span id="font">30th&nbsp;November&nbsp;2021</span>
                <span class="line2"></span>
            </div>
            <div class="imageSquare">
                <img src="img/image1.jpg" alt="" class="topimage" />
                <div class="smalltitle">關於「永青饅頭」:</div>
                <div class="decorate"></div>
                <div class="topcontent">
                    在大家還在與睡神搏鬥的同時，早已有一群早起的人們正準備出門為生活努力打拼著，
                    <br>與此同時，哪怕是多麼不起眼的早餐都將能撫慰人心，
                    <br>更何況是一家富含滿滿用心與熱忱所成立的多年手工饅頭店呢，
                    <br>看著伯伯認真的神情與專業的揉麵手勢，就知道，這裡的饅頭絕對不簡單!
                    <br>慢工出細活，看似平凡的饅頭裡，包含著大大的學問，
                    <br>也成為街訪鄰居口中的平民巷口早餐好選擇!
                    <br>(tips:毛巾饅頭建議提前預約(芋頭為限量口味),早點去才有熱騰騰剛出爐的可以購買,
                    <br>也可選擇冷得回家蒸，整體口感也是鬆軟派)
                </div>
            </div>
            <div class="leftSquare">
                <img src="img/image2.jpg" alt="" class="image" />
                <div class="rightcontent">
                    <strong>爆漿黑糖包</strong>
                    <div class="decorateline"></div>
                    微甜的黑糖麵皮裡，香甜濃厚的黑糖漿成了此饅頭最大的亮點。吃著熱呼呼的爆汁黑糖餡，幸福指數瞬間爆棚！而平凡外層與濃郁的內餡，如同一位外表樸素卻富有學問的朋友，與他交心越久，越能發現他的特別與層次感，平凡中帶點神祕!
                </div>
            </div>
            <div class="rightSquare">
                <img src="img/image3.jpg" alt="" class="image" />
                <div class="leftcontent">
                    <strong>毛巾饅頭(綠豆沙口味)</strong>
                    <div class="decorateline"></div>
                    這家饅頭店的最大特色，就是伯伯自己研發的毛巾饅頭，有紅豆、綠豆及芋泥餡可選擇，裡面豆沙餡不會死甜，吃多了也不膩口；其細膩綿密的口感，在嘴中也會瞬間化開，留下滿腔的甜蜜餘韻，在你食用每一口白饅頭的同時還能吃到滿滿的內餡，實現簡單的快樂~
                </div>
            </div>
            <div class="leftSquare">
                <img src="img/image4.jpg" alt="" class="image" />
                <div class="rightcontent">
                    <strong>黑糖葡萄饅頭</strong>
                    <div class="decorateline"></div>
                    將葡萄乾加在黑糖饅頭裡，使它在被咀嚼的同時，有了更多層次的口感，營養程度也跟著提升，食用起來也較無負擔，不會讓不想吃普通饅頭又想吃健康一點的你覺得單調乏味，是早晨及放學下午茶的快樂首選
                </div>
            </div>
            <div class="time">
                地點:高雄市鹽埕區大公路
                <div class="number">60</div>
                號 <br />營業時間 : 一 ~ 日 :
                <div class="number">7:00-18:00</div>
            </div>
            <div class="uber">
                <a href="https://m.uber.com/looking?drop%5B0%5D=%7B%22latitude%22%3A22.6272701%2C%22longitude%22%3A120.2837321%2C%22addressLine1%22%3A%22%E6%B0%B8%E9%9D%92%E9%A3%9F%E5%93%81%E9%A5%85%E9%A0%AD%E6%89%B9%E7%99%BC%22%2C%22addressLine2%22%3A%22%E5%8F%B0%E6%B9%BE%E9%AB%98%E9%9B%84%E5%B8%82%E7%9B%90%E5%9F%95%E5%8C%BA%E5%A4%A7%E5%85%AC%E8%B7%AF%22%2C%22id%22%3A%22ChIJazmh8HAEbjQRjBH0roH8Bmc%22%2C%22provider%22%3A%22google_places%22%7D" target="_blank"><img src="../../common img/uber.png" id="bookingimg" alt="" width="60" height="60" /></a>
            </div>
            <!--鼎新刈包-->
            <div class="articalTitle">
                誰將正在熟睡的你我叫起 難道是那陣陣飄香嗎? 尋尋覓覓 驀然回首 那記刈中的映象浮上眼前...
            </div>
            <div class="lines">
                <span class="line1"></span>
                <span id="font">30th&nbsp;November&nbsp;2021</span>
                <span class="line2"></span>
            </div>
            <div class="imageSquare">
                <img src="img/image5.jpg" alt="" class="topimage" />
                <div class="smalltitle">關於「鼎新刈包」:</div>
                <div class="decorate"></div>
                <div class="topcontent">
                    在不起眼的巷弄裡，就是有這麼一家不靠醒目招牌招攬客人的個性美食。
                    <br>靠得只有老闆熟練的滷製手藝和極具特色的彩色刈包，
                    <br>雖然只在此處經營五年時間，不過卻是附近鄰居好評不斷的口袋名單、品質保證，
                    <br>總想著難道是有奢麼獨家秘辛?!但，實際走訪認為並非如此，
                    <br>食材固然好吃、真材實料，不過真正致勝的關鍵，是那老闆好客的個性還有街訪之間的人情味吧~
                    <br>(tips:假日購買才有高機率碰到隱藏版的刈包顏色及限量的部位可挑選,
                    <br>也可先行告知要肉質的肥瘦比例和想要的刈包顏色)
                </div>
            </div>
            <div class="leftSquare">
                <img src="img/image6.jpg" alt="" class="image" />
                <div class="rightcontent">
                    <strong>精選刈包</strong>
                    <div class="decorateline"></div>
                    不用怕不同味道的外皮蓋住了爌肉的香氣，因為刈包皮本身是沒什麼味道的，但如果想要讓刈包增添額外的風味層次，就可以選擇黑糖或抹茶口味，茶香的尾韻及黑糖的香氣，既沒有搶走主角的風采，又將整體推向另一種美味。肉質方面也可自由做出選擇，不管是豬肉紮實的肉質，還是入口即化的油脂，都能在口中的達到了適當的平衡，不柴不膩，恰如其分
                </div>
            </div>
            <div class="rightSquare">
                <img src="img/image7.jpg" alt="" class="image" />
                <div class="leftcontent">
                    <strong>膠原蛋白筋肉刈包 (隱藏版)</strong>
                    <div class="decorateline"></div>
                    如果夠幸運的話，就能夠吃到限量版的豬筋瘦肉，數量稀有到可遇而不可求！也正因為老闆已經提前滷製好，所以別怕整塊瘦肉在咀嚼時會過柴，而富滿膠質的瘦肉，也會如同奶油般塗抹於整個雙唇，並讓雙唇瞬間覆蓋光澤感，大大的滿足、小小的幸福
                </div>
            </div>
            <div class="time">
                地點:高雄市鹽埕區新樂街
                <div class="number">114-2</div>
                號 <br />營業時間 : 一 ~ 日 :
                <div class="number">10:00-17:30</div>
            </div>
            <div class="uber">
                <a href="https://m.uber.com/looking?drop%5B0%5D=%7B%22latitude%22%3A22.6238978%2C%22longitude%22%3A120.2855719%2C%22addressLine1%22%3A%22%E9%BC%8E%E6%96%B0%E5%88%88%E5%8C%85%22%2C%22addressLine2%22%3A%22%E5%8F%B0%E6%B9%BE%E9%AB%98%E9%9B%84%E5%B8%82%E7%9B%90%E5%9F%95%E5%8C%BA%E6%96%B0%E4%B9%90%E8%A1%97%22%2C%22id%22%3A%22ChIJTWMFqsQFbjQRnht-pysHngw%22%2C%22provider%22%3A%22google_places%22%7D" target="_blank"><img src="../../common img/uber.png" id="bookingimg" alt="" width="60" height="60" /></a>
            </div>
            <!--王家豆花-->
            <div class="articalTitle">
                夏日炎炎 秋去冬來 誰將能溫暖你我的心 ; 而最純樸熟悉的味道...亦成為返鄉子弟最深的眷戀
            </div>
            <div class="lines">
                <span class="line1"></span>
                <span id="font">01th&nbsp;December&nbsp;2021</span>
                <span class="line2"></span>
            </div>
            <div class="imageSquare">
                <img src="img/image8.jpg" alt="" class="topimage" />
                <div class="smalltitle">關於「王家豆花」:</div>
                <div class="decorate"></div>
                <div class="topcontent">
                    在午餐時間享受傳統美食的洗禮之餘，
                    <br>一定"渴"望一個完美的收尾來結束這慵懶的午後時光~
                    <br>而此時的王家豆花，儼然成為最天然傳統的好選擇---最純樸簡單的兒時記憶。
                    <br>老闆用了快一甲子時間經營，並前往廣西學習近30年的豆花手藝並引用到台灣販賣，
                    <br>就算歷經了大眾對食品安全的疑慮興起，
                    <br>但他依然是十幾年不曾動搖的好味道，品質保證!
                </div>
            </div>
            <div class="leftSquare">
                <img src="img/image9.jpg" alt="" class="image" />
                <div class="rightcontent">
                    <strong>薏仁+綠豆湯</strong>
                    <div class="decorateline"></div>
                    兩大主角(綠豆和薏仁)在這個甜品中融合得恰到好處，並不會互相搶奪對方的味道，也喝得出兩者最單純的清甜，用料也非常實在，而杯中的綠豆薏仁顆粒使你在食用的當下也具有一定的飽足感！至於食材處理的方面也不馬虎，輕輕咀嚼就能輕鬆下嚥，清爽型夏季飲品
                </div>
            </div>
            <div class="rightSquare">
                <img src="img/image10.jpg" alt="" class="image" />
                <div class="leftcontent">
                    <strong>薏仁牛奶 / 綠豆牛奶</strong>
                    <div class="decorateline"></div>
                    如果想吃的更有營養，也可以選擇添加牛奶，乳香中帶點薏仁與綠豆的香氣，是非常自然的味道，不會有一絲的化學感，亦不用怕會有什麼化學添加物，對家長而言，也能很安心的給自己的孩子飲用!
                </div>
            </div>
            <div class="leftSquare">
                <img src="img/image11.jpg" alt="" class="image" />
                <div class="rightcontent">
                    <strong>珍珠豆花</strong>
                    <div class="decorateline"></div>
                    這家老店最大的亮點，絕對非豆花莫屬了!既有綿密細緻又紮實的口感，還有每次放進口中的那種黃豆香氣...令人難以忘懷，四季皆宜。最後再加上老闆自行研發的糖水獨家比例加持，讓樸素的豆花不再單調，儼然成了畫龍點睛之筆，賦予了豆花生命與層次
                </div>
            </div>
            <div class="time">
                地點:高雄市鹽埕區新樂街
                <div class="number">213-6</div>
                號 <br />營業時間 : 一 ~ 五 :
                <div class="number">11:00-20:30</div>
                &nbsp;| &nbsp;六、日 :
                <div class="number">11:00-20:00</div>
            </div>
            <div class="uber">
                <a href="https://m.uber.com/looking?drop%5B0%5D=%7B%22latitude%22%3A22.6253934%2C%22longitude%22%3A120.2822719%2C%22addressLine1%22%3A%22%E7%9B%90%E5%9F%95%E7%8E%8B%E5%AE%B6%E6%89%8B%E5%B7%A5%E8%B1%86%E8%8A%B1%22%2C%22addressLine2%22%3A%22%E5%8F%B0%E6%B9%BE%E9%AB%98%E9%9B%84%E5%B8%82%E7%9B%90%E5%9F%95%E5%8C%BA%E6%96%B0%E4%B9%90%E8%A1%97%22%2C%22id%22%3A%22ChIJ5_mQNncEbjQR_UAAgVFBYGQ%22%2C%22provider%22%3A%22google_places%22%7D" target="_blank"><img src="../../common img/uber.png" id="bookingimg" alt="" width="60" height="60" /></a>
            </div>
        </div>
    </main>
    <footer>
        <div class="footerSquare">
            <a href="#body">
                <div id="back"><i class="fas fa-angle-double-up"></i> Go to Top</div>
            </a>
            <div class="contactus">CONTACT US</div>
            <div id="igiconii">
                <div id="igicondiv">
                    <a href="https://www.instagram.com/hola._.foodie/" target="_blank"><img src="../../common img/igicon.png" alt="" class="igicon" /></a>
                </div>
            </div>
            <div class="footercontent">
                <p>TEL:07-5252000</p>
                <p>EMAIL:holafoodie@gmail.com</p>
                <p>ADDRESS:No.70,Lianhai Rd, Gushan District, Kaohsiung City,804</p>
                <p>SERVICE HOUR:09:00~17:00</p>
                <p id="copyright">© 2021 Hola.foodie all rights reserved</p>
            </div>
        </div>
    </footer>
</body>

</html>