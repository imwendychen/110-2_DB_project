<?php
    include("connect.php")
?>

<?php
        $title = $_POST['title'];
        $slogan = $_POST['slogan'];
        $subtitle = $_POST['subtitle'];
        $content = $_POST['content'];

        $sql = "UPDATE blog SET title='$title',slogan='$slogan',subtitle='$subtitle',content='$content' ";
        if ($conn->query($sql)) {
            echo "
            更新成功
            ";
        }
        else {
            echo "
            失敗
            ";
        }
?>