<!DOCTYPE html>
<html>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

<head>
    <title>小賀的店</title>
    <!-- 字體 -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=EB+Garamond&family=Noto+Serif+TC:wght@500&family=PT+Serif&family=Vollkorn&display=swap" rel="stylesheet">
    <!-- bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous" />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <!-- css js -->
    <link href="../../menunav.css" rel="stylesheet" />
    <link href="hustore.css" rel="stylesheet" />
    <link rel="stylesheet" href="hustore_screen.css" />
    <link rel="stylesheet" href="../rating.css" />
    <script src="../../common.js"></script>
    <link rel="icon" type="image/x-icon" href="../../common img/titleicon.png" />
    <!-- font awesome -->
    <script defer src="https://use.fontawesome.com/releases/v5.0.10/js/all.js" integrity="sha384-slN8GvtUJGnv6ca26v8EzVaR9DC58QEwsIk9q1QXdCU8Yu8ck/tL/5szYlBbqmS+" crossorigin="anonymous"></script>
</head>

<body id="body">
    <header>
        <nav class="navbarr navbar-light bg-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="../../主頁/yanchengtour.php">
                    <img src="../../common img/titleicon.png" alt="" width="65" height="65" class="d-inline-block align-text-top" />
                    <div id="brandname">Hola Foodie</div>
                </a>
                <button id="mobile-menu">
                    <img src="../../common img/more.png" alt="" class="menuicon" />
                </button>
                <form action="/action.php" id="form">
                    <a href="../../搜尋/index.php">
                        <label for="searchblank" id="search"><img src="../../common img/magnifier.png" id="magnifier"></label>
                        <input type="text" id="searchkey" name="searchblank">
                    </a>
                </form>
            </div>
        </nav>
        <ul class="nav">
            <li class="nav-item">
                <a class="nav-link" href="../../主頁/yanchengtour.php">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../../post/phase2.php">Posts</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../關於我們/aboutus.php">About Us</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../../登入/index.php">Member Area</a>
            </li>
        </ul>
        <div id="mobilenavbar">
            <div class="mobilenav-item">
                <a class="mnav-link" href="../../主頁/yanchengtour.php">Home</a>
            </div>
            <div class="mobilenav-item">
                <a class="mnav-link" href="../../post/phase2.php">Posts</a>
            </div>
            <div class="mobilenav-item">
                <a class="mnav-link" href="../關於我們/aboutus.php">About Us</a>
            </div>
            <div class="mobilenav-item">
                <a class="mnav-link" href="../../登入/index.php">Member Area</a>
            </div>
        </div>
    </header>
    <div class="Title">
        <div class="content">
            小賀的店
            <br />真正達人的店，只賣一兩樣，只為了專心為你。
        </div>
    </div>
    <main>
        <div class="article" id="article">
            <div class="rating">
                <form method="POST">
                    <a class="rating" href="../評分系統/index.php?Post_Id=13">新增評分</a>
                </form>
            </div>
            <br><br>
            <form method="POST" action="../評分系統/saved.php?Post_Id=13" class="">
                <button><img title="快來收藏文章吧" src="../../common img/save-instagram.png" width="35px"></button>
            </form>
            <div class="articalTitle">
                令人流連忘返的雞腿排鐵板麵就在這～～
            </div>
            <div class="lines">
                <span class="line1"></span>
                <span id="font">12th&nbsp;December&nbsp;2021</span>
                <span class="line2"></span>
            </div>
            <div class="imageSquare">
                <img src="img/image2.jpg" alt="" class="topimage" />
                <div class="topcontent">
                    小賀的店我回訪很多次了>< <br>這裡跟傳統夜市牛排不一樣
                        <br>主打嫩煎腿排，也只有賣這一樣
                </div>
            </div>
            <div class="imageSquare">
                <div class="smalltitle">🔅嫩煎腿排麵 $110（紅醬/黑醬/綜合）</div>
                <div class="decorate"></div>
                <div class="topcontent">
                    這次我點綜合的醬（因為沒吃過紅醬，想嘗試又很哈黑胡椒）
                    <br>紅醬有點甜酸的感覺，
                    <br>不過因為有黑醬中和所以口味上蠻剛好的！喜歡😻
                    <br>腿排上淋的是蜂蜜芥末醬，
                    <br>吃起來很搭又解膩！
                    <br>腿排真的超嫩又多汁😋
                    <br>真的推爆❤️
                </div>
            </div>
            <div class="imageSquare">
                <div class="smalltitle">🔅紅茶牛奶 $30（點主餐可以以$20元加購）</div>
                <div class="decorate"></div>
                <div class="topcontent">
                    算中規中矩的鮮奶茶，
                    <br>紅茶甜度沒有很高。
                    <br>小編喜歡❤️過關ଘ(੭ˊ꒳​ˋ)੭✧
                </div>
            </div>
            <div class="time">
                📍小賀的店
                <br>營業時間 :11:00-14:30 16:30-19:30（週末公休）
                <br>電話：0975-253-689
                <br>地址：807 高雄市三民區河北二路108號
            </div>
            <div class="uber">
                <a href="https://reurl.cc/QLeeab" target="_blank"><img src="../../common img/uber.png" id="bookingimg" alt="" width="60" height="60" /></a>
                <a href="../../booking/booking/booking.html" target="_blank"><img src="../../common img/booking.png" id="bookingimg" alt="" width="60" height="60" /></a>
            </div>
        </div>
    </main>
    <footer>
        <div class="footerSquare">
            <a href="#body">
                <div id="back"><i class="fas fa-angle-double-up"></i> Go to Top</div>
            </a>
            <div class="contactus">CONTACT US</div>
            <div id="igiconii">
                <div id="igicondiv">
                    <a href="https://www.instagram.com/hola._.foodie/" target="_blank"><img src="../../common img/igicon.png" alt="" class="igicon" /></a>
                </div>
            </div>
            <div class="footercontent">
                <p>TEL:07-5252000</p>
                <p>EMAIL:holafoodie@gmail.com</p>
                <p>ADDRESS:No.70,Lianhai Rd, Gushan District, Kaohsiung City,804</p>
                <p>SERVICE HOUR:09:00~17:00</p>
                <p id="copyright">© 2021 Hola.foodie all rights reserved</p>
            </div>
        </div>
    </footer>
</body>

</html>