create TABLE demo (
    id INT(11) NOT NULL AUTO_INCREMENT,
    img VARCHAR(50) NOT NULL,
    classify INT(11) NOT NULL,
    num INT(11) NOT NULL,
    place VARCHAR(50) NOT NULL,
    url VARCHAR(225) NOT NULL,
    PRIMARY KEY ( id ) USING BTREE
);

INSERT INTO demo VALUES('1','總照片/恆香1.jpg','1','1','恆香·Hen Pon','../內文頁/恆香/henpon.php');
INSERT INTO demo VALUES('2','總照片/恆香2.jpg','1','2','恆香·Hen Pon','../內文頁/恆香/henpon.php');
INSERT INTO demo VALUES('3','總照片/恆香3.jpg','1','3','恆香·Hen Pon','../內文頁/恆香/henpon.php');
INSERT INTO demo VALUES('4','總照片/小籠包1.jpg','2','1','永和小籠包','../內文頁/永和/porkbun.php');
INSERT INTO demo VALUES('5','總照片/小籠包2.jpg','2','2','永和小籠包','../內文頁/永和/porkbun.php');
INSERT INTO demo VALUES('6','總照片/小籠包3.jpg','2','3','永和小籠包','../內文頁/永和/porkbun.php');
INSERT INTO demo VALUES('7','總照片/船麵1.jpg','4','1','大城老船麵','../內文頁/大城老船麵/boatnoodle.php');
INSERT INTO demo VALUES('8','總照片/船麵2.jpg','4','2','大城老船麵','../內文頁/大城老船麵/boatnoodle.php');
INSERT INTO demo VALUES('9','總照片/船麵3.jpg','4','3','大城老船麵','../內文頁/大城老船麵/boatnoodle.php');
INSERT INTO demo VALUES('10','總照片/植福餅1.jpg','5','1','植福餅','../內文頁/植福餅/wheelcake.php');
INSERT INTO demo VALUES('11','總照片/植福餅2.jpg','5','2','植福餅','../內文頁/植福餅/wheelcake.php');
INSERT INTO demo VALUES('12','總照片/植福餅3.jpg','5','3','植福餅','../內文頁/植福餅/wheelcake.php');
INSERT INTO demo VALUES('13','總照片/重慶1.jpg','6','1','玲波重慶小麵','../內文頁/玲波/lingpo.php');
INSERT INTO demo VALUES('14','總照片/重慶2.jpg','6','2','玲波重慶小麵','../內文頁/玲波/lingpo.php');
INSERT INTO demo VALUES('15','總照片/重慶3.jpg','6','3','玲波重慶小麵','../內文頁/玲波/lingpo.php');
INSERT INTO demo VALUES('16','總照片/永青饅頭1.jpg','3','1','鹽埕街邊美食','../內文頁/鹽埕老店/steamed bread.php');
INSERT INTO demo VALUES('17','總照片/王家甜湯2.jpg','3','2','鹽埕街邊美食','../內文頁/鹽埕老店/steamed bread.php');
INSERT INTO demo VALUES('18','總照片/ㄧˋ包好吃3.jpg','3','3','鹽埕街邊美食','../內文頁/鹽埕老店/steamed bread.php');
INSERT INTO demo VALUES('19','總照片/駁二1.jpg','7','1','駁二藝術特區','../內文頁/駁二/pier-2.php');
INSERT INTO demo VALUES('20','總照片/駁二2.jpg','7','2','駁二藝術特區','../內文頁/駁二/pier-2.php');
INSERT INTO demo VALUES('21','總照片/駁二3.jpg','7','3','駁二藝術特區','../內文頁/駁二/pier-2.php');
INSERT INTO demo VALUES('22','總照片/純愛冰菓室1.jpg','8','1','純愛冰菓室','../內文頁/純愛/ice.php');
INSERT INTO demo VALUES('23','總照片/純愛冰菓室2.jpg','8','2','純愛冰菓室','../內文頁/純愛/ice.php');
INSERT INTO demo VALUES('24','總照片/純愛冰菓室3.jpg','8','3','純愛冰菓室','../內文頁/純愛/ice.php');
INSERT INTO demo VALUES('25','總照片/霓虹派對1.jpg','9','1','愛河市集','../內文頁/愛河市集/love river.php');
INSERT INTO demo VALUES('26','總照片/霓虹派對2.jpg','9','2','愛河市集','../內文頁/愛河市集/love river.php');
INSERT INTO demo VALUES('27','總照片/霓虹派對3.jpg','9','3','愛河市集','../內文頁/愛河市集/love river.php');
INSERT INTO demo VALUES('28','總照片/RE earth1.jpg','10','1','RE earth','../內文頁/re_earth/reearth.php');
INSERT INTO demo VALUES('29','總照片/RE earth2.jpg','10','2','RE earth','../內文頁/re_earth/reearth.php');
INSERT INTO demo VALUES('30','總照片/RE earth3.jpg','10','3','RE earth','../內文頁/re_earth/reearth.php');
INSERT INTO demo VALUES('31','總照片/金漢城1.jpg','11','1','金漢城韓國料理','../內文頁/金漢城/korean.php');
INSERT INTO demo VALUES('32','總照片/金漢城2.jpg','11','2','金漢城韓國料理','../內文頁/金漢城/korean.php');
INSERT INTO demo VALUES('33','總照片/金漢城3.jpg','11','3','金漢城韓國料理','../內文頁/金漢城/korean.php');
INSERT INTO demo VALUES('34','總照片/溫咖哩1.jpg','12','1','溫咖裏Wunkalee','../內文頁/溫咖裏/curry.php');
INSERT INTO demo VALUES('35','總照片/溫咖哩2.jpg','12','2','溫咖裏Wunkalee','../內文頁/溫咖裏/curry.php');
INSERT INTO demo VALUES('36','總照片/溫咖哩3.jpg','12','3','溫咖裏Wunkalee','../內文頁/溫咖裏/curry.php');
INSERT INTO demo VALUES('37','總照片/小賀1.jpg','13','1','小賀的店','../內文頁/小賀的店/hustore.php');
INSERT INTO demo VALUES('38','總照片/小賀2.jpg','13','2','小賀的店','../內文頁/小賀的店/hustore.php');
INSERT INTO demo VALUES('39','總照片/小賀3.jpg','13','3','小賀的店','../內文頁/小賀的店/hustore.php');
INSERT INTO demo VALUES('40','總照片/ramenichi1.jpg','14','1','らーめん壱Ramen Ichi','../內文頁/Ramen_Ichi/ramen.php');
INSERT INTO demo VALUES('41','總照片/ramenichi2.jpg','14','2','らーめん壱Ramen Ichi','../內文頁/Ramen_Ichi/ramen.php');
INSERT INTO demo VALUES('42','總照片/ramenichi3.jpg','14','3','らーめん壱Ramen Ichi','../內文頁/Ramen_Ichi/ramen.php');
INSERT INTO demo VALUES('43','總照片/品樂1.jpg','15','3','品樂食堂','../內文頁/品樂食堂/pinle.php');
INSERT INTO demo VALUES('44','總照片/品樂2.jpg','15','3','品樂食堂','../內文頁/品樂食堂/pinle.php');
INSERT INTO demo VALUES('45','總照片/品樂3.jpg','15','3','品樂食堂','../內文頁/品樂食堂/pinle.php');
INSERT INTO demo VALUES('46','總照片/sugoeat1.jpg','16','1','樹·Sugoeat','../內文頁/sugoeat/sugoeat.php');
INSERT INTO demo VALUES('47','總照片/sugoeat2.jpg','16','2','樹·Sugoeat','../內文頁/sugoeat/sugoeat.php');
INSERT INTO demo VALUES('48','總照片/sugoeat3.jpg','16','3','樹·Sugoeat','../內文頁/sugoeat/sugoeat.php');
INSERT INTO demo VALUES('49','總照片/阿嬤油飯1.jpg','17','1','阿嬤油飯','../內文頁/阿嬤油飯/oilrice.php');
INSERT INTO demo VALUES('50','總照片/阿嬤油飯2.jpg','17','2','阿嬤油飯','../內文頁/阿嬤油飯/oilrice.php');
INSERT INTO demo VALUES('51','總照片/阿嬤油飯3.jpg','17','3','阿嬤油飯','../內文頁/阿嬤油飯/oilrice.php');
INSERT INTO demo VALUES('52','總照片/米糕城1.jpg','18','1','米糕城','../內文頁/米糕城/ricecake.php');
INSERT INTO demo VALUES('53','總照片/米糕城2.jpg','18','2','米糕城','../內文頁/米糕城/ricecake.php');
INSERT INTO demo VALUES('54','總照片/米糕城3.jpg','18','3','米糕城','../內文頁/米糕城/ricecake.php');
INSERT INTO demo VALUES('55','總照片/朱QQ1.jpg','19','1','朱爺爺QQ蛋地瓜球','../內文頁/朱QQ/qqball.php');
INSERT INTO demo VALUES('56','總照片/朱QQ2.jpg','19','2','朱爺爺QQ蛋地瓜球','../內文頁/朱QQ/qqball.php');
INSERT INTO demo VALUES('57','總照片/朱QQ3.jpg','19','3','朱爺爺QQ蛋地瓜球','../內文頁/朱QQ/qqball.php');
INSERT INTO demo VALUES('58','總照片/全心1.jpg','20','1','全心丼飯','../內文頁/全心/donburi.php');
INSERT INTO demo VALUES('59','總照片/全心2.jpg','20','2','全心丼飯','../內文頁/全心/donburi.php');
INSERT INTO demo VALUES('60','總照片/全心3.jpg','20','3','全心丼飯','../內文頁/全心/donburi.php');
INSERT INTO demo VALUES('61','總照片/超級鳥叢林1.jpg','21','1','超級鳥&霓虹叢林','../內文頁/超級鳥/oldstore.php');
INSERT INTO demo VALUES('62','總照片/超級鳥叢林2.jpg','21','2','超級鳥&霓虹叢林','../內文頁/超級鳥/oldstore.php');
INSERT INTO demo VALUES('63','總照片/超級鳥叢林3.jpg','21','3','超級鳥&霓虹叢林','../內文頁/超級鳥/oldstore.php');
INSERT INTO demo VALUES('64','總照片/真愛碼頭流音館1.jpg','22','1','真愛碼頭流音館','../內文頁/流音館/music.php');
INSERT INTO demo VALUES('65','總照片/真愛碼頭流音館2.jpg','22','2','真愛碼頭流音館','../內文頁/流音館/music.php');
INSERT INTO demo VALUES('66','總照片/真愛碼頭流音館3.jpg','22','3','真愛碼頭流音館','../內文頁/流音館/music.php');
INSERT INTO demo VALUES('67','總照片/兜兜圈1.jpg','23','1','兜兜圈','../內文頁/兜兜圈/doughnut.php');
INSERT INTO demo VALUES('68','總照片/兜兜圈2.jpg','23','2','兜兜圈','../內文頁/兜兜圈/doughnut.php');
INSERT INTO demo VALUES('69','總照片/兜兜圈3.jpg','23','3','兜兜圈','../內文頁/兜兜圈/doughnut.php');
INSERT INTO demo VALUES('70','總照片/小聲點1.jpg','24','1','小聲點酒吧','../內文頁/小聲點酒館/bar.php');
INSERT INTO demo VALUES('71','總照片/小聲點2.jpg','24','2','小聲點酒吧','../內文頁/小聲點酒館/bar.php');
INSERT INTO demo VALUES('72','總照片/小聲點3.jpg','24','3','小聲點酒吧','../內文頁/小聲點酒館/bar.php');
INSERT INTO demo VALUES('73','總照片/大港橋1.jpg','25','1','大港橋','../內文頁/大港橋/bridge.php');
INSERT INTO demo VALUES('74','總照片/大港橋2.jpg','25','2','大港橋','../內文頁/大港橋/bridge.php');
INSERT INTO demo VALUES('75','總照片/大港橋3.jpg','25','3','大港橋','../內文頁/大港橋/bridge.php');



















