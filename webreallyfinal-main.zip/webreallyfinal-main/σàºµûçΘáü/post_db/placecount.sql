create TABLE placecount(r_name varchar(50) NOT NULL, count int(11));

INSERT INTO `placecount` VALUES('恆香·Hen Pon','1');
INSERT INTO `placecount` VALUES('永和小籠包','2');
INSERT INTO `placecount` VALUES('鹽埕街邊美食','3');;
INSERT INTO `placecount` VALUES('大城老船麵','4');
INSERT INTO `placecount` VALUES('植福餅','5');
INSERT INTO `placecount` VALUES('玲波重慶小麵','6');
INSERT INTO `placecount` VALUES('駁二藝術特區','7');
INSERT INTO `placecount` VALUES('純愛冰菓室','8');
INSERT INTO `placecount` VALUES('霓虹派對','9');
INSERT INTO `placecount` VALUES('RE earth','10');
INSERT INTO `placecount` VALUES('金漢城韓國料理','11');
INSERT INTO `placecount` VALUES('溫咖裏Wunkalee','12');
INSERT INTO `placecount` VALUES('小賀的店','13');
INSERT INTO `placecount` VALUES('らーめん壱Ramen Ichi','14');
INSERT INTO `placecount` VALUES('品樂食堂','15');
INSERT INTO `placecount` VALUES('樹·Sugoeat','16');
INSERT INTO `placecount` VALUES('阿嬤油飯','17');
INSERT INTO `placecount` VALUES('米糕城','18');
INSERT INTO `placecount` VALUES('朱爺爺QQ蛋地瓜球','19');
INSERT INTO `placecount` VALUES('全心丼飯','20');
INSERT INTO `placecount` VALUES('超級鳥&霓虹叢林','21');
INSERT INTO `placecount` VALUES('真愛碼頭流音館','22');
INSERT INTO `placecount` VALUES('兜兜圈','23');
INSERT INTO `placecount` VALUES('小聲點酒吧','24');
INSERT INTO `placecount` VALUES('大港橋','25');

