<?php
include("connect.php");
?>
<!DOCTYPE html>
<html>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<head>
<title>
        new post
    </title>
    <!-- 字體 -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=EB+Garamond&family=Noto+Serif+TC:wght@500&family=PT+Serif&family=Vollkorn&display=swap" rel="stylesheet">
    <!-- bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous" />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <!-- css js -->
    <link href="menunav.css" rel="stylesheet" />
    <link href="postedit.css" rel="stylesheet" />
    <link href="postedit_rwd.css" rel="stylesheet" />
    <link rel="stylesheet" href="music_screen.css" />

    <script src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.8.0.js"></script>
    <script src="postedit.js"></script>
    <script src="common.js"></script>
    <script src="show.js"></script>
    <link rel="icon" type="image/x-icon" href="common img/titleicon.png" />
    <!-- font awesome -->
    <script defer src="https://use.fontawesome.com/releases/v5.0.10/js/all.js" integrity="sha384-slN8GvtUJGnv6ca26v8EzVaR9DC58QEwsIk9q1QXdCU8Yu8ck/tL/5szYlBbqmS+" crossorigin="anonymous"></script>

</head>
<body>
    <?php
        //$id = $_POST['....']; 從連到這的檔案抓名字
        $id = 0;
        $title = $blog_data[$id]['title'];
        $slogan = $blog_data[$id]['slogan'];
        $subtitle = $blog_data[$id]['subtitle'];
        $content = $blog_data[$id]['content'];
        
        //......
    ?>
    <form  method="post" enctype="multipart/form-data" onSubmit="return InputCheck(this)" action="update.php">

        <input type="text" name="test1" class="show_title" value="<?php echo "title:$title"; ?>" required>
        <input type="text" name="test2" class="show_title" value="<?php echo "slogan:$slogan"; ?>" required>
        <input type="text" name="test3" class="show_title" value="<?php echo "subtitle:$subtitle"; ?>" required>
        <input type="text" name="test4" class="show_title" value="<?php echo "content:$content"; ?>" required>
       
        
    
        <div>
            <button type="submit" >修改文章</button>
        </div>
    </form>

</body>

</html>