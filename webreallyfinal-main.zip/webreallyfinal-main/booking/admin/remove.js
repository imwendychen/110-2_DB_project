$('#remove').click(function(){
    $('.card-content').remove();
})