<?php
    include("connect.php");
?>

<?php

// $dir = 'web_phase_I/img';
// $name = basename($_FILES["titleimg"]["name"]);
// move_uploaded_file(
//     $_FILES["titleimg"]["tmp_name"],
//     "$dir/$name"
// );


// move_uploaded_file(
//     $_FILES["new_subimg"]["tmp_name"],
//     'img/' . $_FILES["new_subimg"]["name"]
// );

// move_uploaded_file(
//     $_FILES["imgsq1"]["tmp_name"],
//     'img/' . $_FILES["imgsq1"]["name"]
// );

// move_uploaded_file(
//     $_FILES["imgsq2"]["tmp_name"],
//     'img/' . $_FILES["imgsq2"]["name"]
// );

// move_uploaded_file(
//     $_FILES["imgsq3"]["tmp_name"],
//     'img/' . $_FILES["imgsq3"]["name"]
// // );

$title = $_POST['new_title'];
$slogan = $_POST['new_slogan'];

$subtitle = $_POST['new_subtitle'];
$content = $_POST['new_content'];
$time = $_POST['new_time'];
$title_img = 'img/' . $_FILES["titleimg"]["name"];
$subtitle_img = 'img/' . $_FILES["new_subimg"]["name"];
$imgsq_1 = $_FILES["imgsq1"]["name"];
$imgsq_2 = $_FILES["imgsq2"]["name"];
$imgsq_3 = $_FILES["imgsq3"]["name"];
if (isset($_POST['submit'])){
    $file_name = $_FILES["titleimg"]["name"];
    $sql = "INSERT INTO blog (title, titleimg, slogan, subtitle, subtitle_img, content, opening_time, subimg1, subimg2, subimg3) VALUES ('$title','$file_name','$slogan', '$subtitle','$subtitle_img','$content','$time','$imgsq_1','$imgsq_2','$imgsq_3')";
    // use exec() because no results are returned
    $result = $conn->query($sql);
    if($result){
        echo "success";
    }else{
        echo "something went wrong.......<br/>";
        echo "$file_name<br/>";
        echo $imgsq_1;
    }
}

?>

<form action="update_page.php">
    <button type="submit">
        修改此文
    </button>
</form>
<form action="delete.php">
    <button type="submit">
        刪除此文
    </button>
</form>