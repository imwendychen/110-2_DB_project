<?php   
 phpinfo();  
?>
