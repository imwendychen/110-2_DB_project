<!DOCTYPE html>
<html>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

<head>
    <title>永和小籠包</title>
    <!-- 字體 -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=EB+Garamond&family=Noto+Serif+TC:wght@500&family=PT+Serif&family=Vollkorn&display=swap" rel="stylesheet">
    <!-- bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous" />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <!-- css js -->
    <link href="../../menunav.css" rel="stylesheet" />
    <link href="porkbun.css" rel="stylesheet" />
    <link rel="stylesheet" href="porkbun_screen.css" />
    <link rel="stylesheet" href="../rating.css" />
    <script src="../../common.js"></script>
    <link rel="icon" type="image/x-icon" href="../../common img/titleicon.png" />
    <!-- font awesome -->
    <script defer src="https://use.fontawesome.com/releases/v5.0.10/js/all.js" integrity="sha384-slN8GvtUJGnv6ca26v8EzVaR9DC58QEwsIk9q1QXdCU8Yu8ck/tL/5szYlBbqmS+" crossorigin="anonymous"></script>
</head>

<body id="body">
    <header>
        <nav class="navbarr navbar-light bg-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="../../主頁/yanchengtour.php">
                    <img src="../../common img/titleicon.png" alt="" width="65" height="65" class="d-inline-block align-text-top" />
                    <div id="brandname">Hola Foodie</div>
                </a>
                <button id="mobile-menu">
                    <img src="../../common img/more.png" alt="" class="menuicon" />
                </button>
                <form action="/action.php" id="form">
                    <a href="../../搜尋/index.php">
                        <label for="searchblank" id="search"><img src="../../common img/magnifier.png" id="magnifier"></label>
                        <input type="text" id="searchkey" name="searchblank">
                    </a>
                </form>
            </div>
        </nav>
        <ul class="nav">
            <li class="nav-item">
                <a class="nav-link" href="../../主頁/yanchengtour.php">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../../post/phase2.php">Posts</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../關於我們/aboutus.php">About Us</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../../登入/index.php">Member Area</a>
            </li>
        </ul>
        <div id="mobilenavbar">
            <div class="mobilenav-item">
                <a class="mnav-link" href="../../主頁/yanchengtour.php">Home</a>
            </div>
            <div class="mobilenav-item">
                <a class="mnav-link" href="../../post/phase2.php">Posts</a>
            </div>
            <div class="mobilenav-item">
                <a class="mnav-link" href="../關於我們/aboutus.php">About Us</a>
            </div>
            <div class="mobilenav-item">
                <a class="mnav-link" href="../../登入/index.php">Member Area</a>
            </div>
        </div>
    </header>
    <div class="Title">
        <div class="content">
            永和小籠包
            <br />可媲美鼎泰豐的50年好味道
        </div>
    </div>
    <main>
        <div class="article" id="article">
            <div class="rating">
                <form method="POST">
                    <a class="rating" href="../評分系統/index.php?Post_Id=2">新增評分</a>
                </form>
            </div>
            <br><br>
            <form method="POST" action="../評分系統/saved.php?Post_Id=2" class="">
                <button><img title="快來收藏文章吧" src="../../common img/save-instagram.png" width="35px"></button>
            </form>
            <div class="articalTitle">
                隱藏在巷弄裡的美味小籠包
            </div>
            <div class="lines">
                <span class="line1"></span>
                <span id="font">27th&nbsp;September&nbsp;2021</span>
                <span class="line2"></span>
            </div>
            <div class="imageSquare">
                <img src="img/image2.jpg" alt="" class="topimage" />
                <div class="topcontent">
                    店面是路邊小攤販，座位不多，慕名很久終於來訪啦😍😍而且阿公老闆好可愛。
                </div>
            </div>
            <div class="imageSquare">
                <div class="smalltitle">🔅 小籠湯包 $65 / 9顆</div>
                <div class="decorate"></div>
                <div class="topcontent">
                    真的超讚！皮薄餡多，可惜的是上桌時好多顆皮都破掉了，所以我真的不曉得湯汁是不是很多那種。不過肉餡很鮮，也都有鎖住肉汁，九顆才65塊真的超佛～～
                    <br>不過跟鼎泰豐比起來如何我真不知，
                    <br>因為小編沒吃過鼎泰豐（桑心💔
                </div>
            </div>
            <div class="imageSquare">
                <div class="smalltitle">🔅酸辣湯 $30</div>
                <div class="decorate"></div>
                <div class="topcontent">
                    我自己覺得可以不用點欸！把錢拿來買第二籠小籠湯包更好（是有多🐷）與其說是酸辣湯，不如說是普通的羹湯，因為沒有酸也沒有辣🥲🥲
                </div>
            </div>
            <div class="time">
                📍永和小籠湯包
                <br>營業時間 :11:00-19:30
                <br>電話：0912-436-908
                <br>地址：803 高雄市鹽埕區鹽埕街35號
            </div>
            <div class="uber">
                <a href="https://reurl.cc/A744b8" target="_blank"><img src="../../common img/uber.png" id="bookingimg" alt="" width="60" height="60" /></a>
                <a href="../../booking/booking/booking.html" target="_blank"><img src="../../common img/booking.png" id="bookingimg" alt="" width="60" height="60" /></a>
            </div>
        </div>
    </main>
    <footer>
        <div class="footerSquare">
            <a href="#body">
                <div id="back"><i class="fas fa-angle-double-up"></i> Go to Top</div>
            </a>
            <div class="contactus">CONTACT US</div>
            <div id="igiconii">
                <div id="igicondiv">
                    <a href="https://www.instagram.com/hola._.foodie/" target="_blank"><img src="../../common img/igicon.png" alt="" class="igicon" /></a>
                </div>
            </div>
            <div class="footercontent">
                <p>TEL:07-5252000</p>
                <p>EMAIL:holafoodie@gmail.com</p>
                <p>ADDRESS:No.70,Lianhai Rd, Gushan District, Kaohsiung City,804</p>
                <p>SERVICE HOUR:09:00~17:00</p>
                <p id="copyright">© 2021 Hola.foodie all rights reserved</p>
            </div>
        </div>
    </footer>
</body>

</html>