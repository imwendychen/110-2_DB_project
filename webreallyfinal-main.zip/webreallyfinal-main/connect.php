<?php
    $server = "localhost";         # MySQL/MariaDB 伺服器
    $dbuser = "mis_team_20";       # 使用者帳號
    $dbpassword = "2s2hm1424"; # 使用者密碼
    $dbname = "mis_team_20";

    $conn = new mysqli($server, $dbuser, $dbpassword, $dbname);
    if(!$conn){
        die("Error: Failed to connect to database!");
    }

    $data = $conn->query("SELECT * FROM blog");
    $blog_data = $data->fetch_all();
?>