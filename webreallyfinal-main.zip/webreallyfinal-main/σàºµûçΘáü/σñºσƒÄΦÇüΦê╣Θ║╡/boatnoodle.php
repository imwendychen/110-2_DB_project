<!DOCTYPE html>
<html>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

<head>
    <title>大城老船麵 ก๋วยเตี๋ยวเรือโบราณ</title>
    <!-- 字體 -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=EB+Garamond&family=Noto+Serif+TC:wght@500&family=PT+Serif&family=Vollkorn&display=swap" rel="stylesheet">
    <!-- bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous" />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <!-- css js -->
    <link href="../../menunav.css" rel="stylesheet" />
    <link href="boatnoodle.css" rel="stylesheet" />
    <link rel="stylesheet" href="../rating.css" />
    <link rel="stylesheet" href="boatnoodle_screen.css" />
    <script src="../../common.js"></script>
    <link rel="icon" type="image/x-icon" href="../../common img/titleicon.png" />
    <!-- font awesome -->
    <script defer src="https://use.fontawesome.com/releases/v5.0.10/js/all.js" integrity="sha384-slN8GvtUJGnv6ca26v8EzVaR9DC58QEwsIk9q1QXdCU8Yu8ck/tL/5szYlBbqmS+" crossorigin="anonymous"></script>
</head>

<body id="body">
    <header>
        <nav class="navbarr navbar-light bg-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="../../主頁/yanchengtour.php">
                    <img src="../../common img/titleicon.png" alt="" width="65" height="65" class="d-inline-block align-text-top" />
                    <div id="brandname">Hola Foodie</div>
                </a>
                <button id="mobile-menu">
                    <img src="../../common img/more.png" alt="" class="menuicon" />
                </button>
                <form action="/action.php" id="form">
                    <a href="../../搜尋/index.php">
                        <label for="searchblank" id="search"><img src="../../common img/magnifier.png" id="magnifier"></label>
                        <input type="text" id="searchkey" name="searchblank">
                    </a>
                </form>
            </div>
        </nav>
        <ul class="nav">
            <li class="nav-item">
                <a class="nav-link" href="../../主頁/yanchengtour.php">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../../post/phase2.php">Posts</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../關於我們/aboutus.php">About Us</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../../登入/index.php">Member Area</a>
            </li>
        </ul>
        <div id="mobilenavbar">
            <div class="mobilenav-item">
                <a class="mnav-link" href="../../主頁/yanchengtour.php">Home</a>
            </div>
            <div class="mobilenav-item">
                <a class="mnav-link" href="../../post/phase2.php">Posts</a>
            </div>
            <div class="mobilenav-item">
                <a class="mnav-link" href="../關於我們/aboutus.php">About Us</a>
            </div>
            <div class="mobilenav-item">
                <a class="mnav-link" href="../../登入/index.php">Member Area</a>
            </div>
        </div>
    </header>
    <div class="Title">
        <div class="content">
            大城老船麵 ก๋วยเตี๋ยวเรือโบราณ
            <br />就像一秒來到泰國的路邊攤吃飯
        </div>
    </div>
    <main>
        <div class="article" id="article">
            <div class="rating">
                <form method="POST">
                    <a class="rating" href="../評分系統/index.php?Post_Id=4">新增評分</a>
                </form>
            </div>
            <br><br>
            <form method="POST" action="../評分系統/saved.php?Post_Id=4" class="">
                <button><img title="快來收藏文章吧" src="../../common img/save-instagram.png" width="35px"></button>
            </form>
            <div class="articalTitle">
                內裝的電線，桌上鋪的桌巾，還有泰式餐車，毋需去泰國也能體驗
            </div>
            <div class="lines">
                <span class="line1"></span>
                <span id="font">29th&nbsp;September&nbsp;2021</span>
                <span class="line2"></span>
            </div>
            <div class="imageSquare">
                <img src="img/image2.jpg" alt="" class="topimage" />
                <div class="topcontent">
                    這間店的陳設很像台北很有名的老麵攤😍，把泰國的路邊攤搬進室內裡，裝潢也超泰式～
                    <br>總的來說，我們兩個小編都覺得這間的料理很好吃，cp值也不低喔～
                </div>
            </div>
            <div class="imageSquare">
                <div class="smalltitle">🔅 船麵 $120</div>
                <div class="decorate"></div>
                <div class="topcontent">
                    湯汁很濃郁，酸酸辣辣的挺開胃，麵體非常Q彈。裡頭的料有丸子、牛肉、牛筋、豬肉、豬肝，都很好吃！
                    <br>（料給得很足，以這個價格來說cp值很高）肉很嫩～豬肝除外，
                    <br>小編…吃不慣豬肝的味道🥲所以丟給另外一隻小豬編>< </div>
                </div>
                <div class="imageSquare">
                    <div class="smalltitle">🔅烤丸子 $80</div>
                    <div class="decorate"></div>
                    <div class="topcontent">
                        應該是魚漿做的丸子，上面裹著甜甜鹹鹹的醬汁，兩個小編都覺得很讚
                    </div>
                </div>
                <div class="imageSquare">
                    <div class="smalltitle">🔅金拌飯 $40</div>
                    <div class="decorate"></div>
                    <div class="topcontent">
                        上頭放了一顆醃漬過的生蛋黃，旁邊有附酸辣開胃的醬汁，整道料理很適合夏天吃😋
                    </div>
                </div>
                <div class="imageSquare">
                    <div class="smalltitle">🔅招牌椰香冰$60</div>
                    <div class="decorate"></div>
                    <div class="topcontent">
                        有兩球濃郁的椰奶冰淇淋跟一球泰國糯米飯，你沒看錯是飯，上面放了一些醃漬物跟花生粒，
                        <br>蠻好吃不過有點甜膩，兩三個人分著吃比較剛好。
                    </div>
                </div>
                <div class="time">
                    📍 大城老船麵 ก๋วยเตี๋ยวเรือโบราณ
                    <br>營業時間 :11:00-20:00
                    <br>電話：07-261-9619
                    <br>地址：800 高雄市新興區復橫一路268號
                </div>
                <div class="uber">
                    <a href="https://reurl.cc/NA44l5" target="_blank"><img src="../../common img/uber.png" id="bookingimg" alt="" width="60" height="60" /></a>
                    <a href="../../booking/booking/booking.html" target="_blank"><img src="../../common img/booking.png" id="bookingimg" alt="" width="60" height="60" /></a>
                </div>
            </div>
    </main>
    <footer>
        <div class="footerSquare">
            <a href="#body">
                <div id="back"><i class="fas fa-angle-double-up"></i> Go to Top</div>
            </a>
            <div class="contactus">CONTACT US</div>
            <div id="igiconii">
                <div id="igicondiv">
                    <a href="https://www.instagram.com/hola._.foodie/" target="_blank"><img src="../../common img/igicon.png" alt="" class="igicon" /></a>
                </div>
            </div>
            <div class="footercontent">
                <p>TEL:07-5252000</p>
                <p>EMAIL:holafoodie@gmail.com</p>
                <p>ADDRESS:No.70,Lianhai Rd, Gushan District, Kaohsiung City,804</p>
                <p>SERVICE HOUR:09:00~17:00</p>
                <p id="copyright">© 2021 Hola.foodie all rights reserved</p>
            </div>
        </div>
    </footer>
</body>

</html>