<?
include ("../登入/config.php");
?>
<!DOCTYPE html>
<html>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

<head>
    <title>
        new post
    </title>
    <!-- 字體 -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=EB+Garamond&family=Noto+Serif+TC:wght@500&family=PT+Serif&family=Vollkorn&display=swap" rel="stylesheet">
    <!-- bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous" />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <!-- css js -->
    <link href="../menunav.css" rel="stylesheet" />
    <link href="postedit.css" rel="stylesheet" />
    <link href="postedit_rwd.css" rel="stylesheet" />
    <link rel="stylesheet" href="music_screen.css" />

    <script src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.8.0.js"></script>
    <script src="postedit.js"></script>
    <script src="common.js"></script>
    <script src="show.js"></script>
    <link rel="icon" type="image/x-icon" href="common img/titleicon.png" />
    <!-- font awesome -->
    <script defer src="https://use.fontawesome.com/releases/v5.0.10/js/all.js" integrity="sha384-slN8GvtUJGnv6ca26v8EzVaR9DC58QEwsIk9q1QXdCU8Yu8ck/tL/5szYlBbqmS+" crossorigin="anonymous"></script>
</head>

<style>
    .pic1{
        width: 500px;
    }
    .hide {
        display: none;
    }
</style>



<body id="bodyedit">
    <header>
        <nav class="navbarr navbar-light bg-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="主頁/yanchengtour.php">
                    <img src="../common img/titleicon.png" alt="" width="65" height="65" class="d-inline-block align-text-top" />
                    <div id="brandname">Hola Foodie</div>
                </a>
                <button id="mobile-menu">
                    <img src="../common img/more.png" alt="" class="menuicon" />
                </button>
                <form action="/action.php" id="form">
                    <a href="搜尋/index.php">
                        <label for="searchblank" id="search"><img src="../common img/magnifier.png" id="magnifier"></label>
                        <input type="text" id="searchkey" name="searchblank">
                    </a>
                </form>
            </div>
        </nav>
        <ul class="nav">
            <li class="nav-item">
                <a class="nav-link" href="主頁/yanchengtour.html">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="post/phase2.php">Posts</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="內文頁/關於我們/aboutus.php">About Us</a>
            </li>
        </ul>
        <div id="mobilenavbar">
            <div class="mobilenav-item">
                <a class="mnav-link" href="主頁/yanchengtour.php">Home</a>
            </div>
            <div class="mobilenav-item">
                <a class="mnav-link" href="post/phase2.php">Posts</a>
            </div>
            <div class="mobilenav-item">
                <a class="mnav-link" href="內文頁/關於我們/aboutus.php">About Us</a>
            </div>
        </div>
    </header>
    <!-- edit start from here -->
    <form class="edit_sec" method="post" enctype="multipart/form-data" onSubmit="return InputCheck(this)" action="upload.php">
        <div class="Title">
            <div class="title_img">
                <input type="file" name="titleimg" id="titleimg" accept="image/gif, image/jpg, image/png" required="required">
                <img id="tmp_pic1" class="pic1" src="#" alt="" />
            </div>
            <div>
                <input type="text" name="new_title" class="show_title" id="edit_title">
            </div>
        </div>
        <main>
            <div class=" article" id="article">
                <div class="articleTitle">
                    <input type="text" name="new_slogan" id="edit_articletitle">
                </div>
                <div class="imageSquare">
                    <div class="subtitle_img">
                        Select subtitle image to upload:
                        <input type="file" name="new_subimg" id="new_subimg" accept="image/gif, image/jpg, image/png" required="required">
                        <img id="tmp_pic2" class="pic2" src="#" alt="" />
                    </div>
                    <div class="smalltitle">
                        <label class="font">subtitle</label>
                        <input type="text" name="new_subtitle">
                    </div>
                    <div class="decorate"></div>
                    <div class="topcontent">
                        <label class="font">content</label>
                        <input type="text" name="new_content">
                    </div>
                </div>
                <div class="photosquare">
                    Select image to upload:
                    <input type="file" name="imgsq1" id="imgsq1" accept="image/gif, image/jpg, image/png" required="required">
                    <img id="tmp_pic3" class="pic3" src="#" alt="" />

                    Select image to upload:
                    <input type="file" name="imgsq2" id="imgsq2" accept="image/gif, image/jpg, image/png" required="required">
                    <img id="tmp_pic4" class="pic4" src="#" alt="" />

                    Select image to upload:
                    <input type="file" name="imgsq3" id="imgsq3" accept="image/gif, image/jpg, image/png" required="required">
                    <img id="tmp_pic5" class="pic5" src="#" alt="" />

                </div>

                <div class="time">
                    <label class="font">opens at:</label>
                    <input type="text" name="new_time">
                </div>
                <input type="submit" value="confirm!" name="submit" id="submitbutton">
            </div>
    </form>

    <script>
        titleimg.onchange = evt => {
            const [file] = titleimg.files
            if (file) {
                tmp_pic1.src = URL.createObjectURL(file);
            }
            titleimg.style.display = none; 
        }

        new_subimg.onchange = evt => {
            const [file] = new_subimg.files
            if (file) {
                tmp_pic2.src = URL.createObjectURL(file);
            }
        }

        imgsq1.onchange = evt => {
            const [file] = imgsq1.files
            if (file) {
                tmp_pic3.src = URL.createObjectURL(file);
            }
        }

        imgsq2.onchange = evt => {
            const [file] = imgsq2.files
            if (file) {
                tmp_pic4.src = URL.createObjectURL(file);
            }
        }

        imgsq3.onchange = evt => {
            const [file] = imgsq3.files
            if (file) {
                tmp_pic5.src = URL.createObjectURL(file);
            }
        }
    </script>

    <!-- <script>
        $('#titleimg').change(function(e) {

            var purl = window.URL || window.webkitURL;

            var file, img;

            if ((file = this.files[0])) {

                img = new Image();

                img.onload = function() {

                    $('#tmp_pic1').attr('src', this.src);

                };

                img.src = purl.createObjectURL(file);

            }

        })
    </script> -->

    </main>
    <footer>
        <div class="footerSquare">
            <a href="#bodyedit">
                <div id="back">
                    <i class="fas fa-angle-double-up"> </i> Go to Top
                </div>
            </a>
            <div class="contactus">
                CONTACT US
            </div>
            <div id="igiconii">
                <div id="igicondiv">
                    <a href="https://www.instagram.com/hola._.foodie/" target="_blank">
                        <img src="common img/igicon.png" alt="" class="igicon" />
                    </a>
                </div>
            </div>
            <div class="footercontent">
                <p> TEL: 07 - 5252000 </p>
                <p> EMAIL: holafoodie @gmail.com </p>
                <p> ADDRESS: No .70, Lianhai Rd, Gushan District, Kaohsiung City, 804 </p>
                <p> SERVICE HOUR: 09: 00~17: 00 </p>
                <p id="copyright"> ©2021 Hola.foodie all rights reserved </p>
            </div>
        </div>
    </footer>
</body>

</html>