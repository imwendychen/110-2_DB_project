<!DOCTYPE html>
<html>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

<head>
    <title>關於我們</title>
    <!-- 字體 -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=EB+Garamond&family=Noto+Serif+TC:wght@500&family=PT+Serif&family=Vollkorn&display=swap" rel="stylesheet">
    <!---->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lora&display=swap" rel="stylesheet">
    <!-- bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <!-- css js -->
    <link href="../../menunav.css" rel="stylesheet">
    <link href="aboutus.css" rel="stylesheet">
    <link rel="stylesheet" href="about_screen.css">
    <script src="../../common.js"></script>
    <link rel="icon" type="image/x-icon" href="../../common img/titleicon.png">
    <!-- font awesome -->
    <script defer src="https://use.fontawesome.com/releases/v5.0.10/js/all.js" integrity="sha384-slN8GvtUJGnv6ca26v8EzVaR9DC58QEwsIk9q1QXdCU8Yu8ck/tL/5szYlBbqmS+" crossorigin="anonymous"></script>
</head>

<body id="body">
    <header>
        <nav class="navbarr navbar-light bg-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="../../主頁/yanchengtour.php">
                    <img src="../../common img/titleicon.png" alt="" width="65" height="65" class="d-inline-block align-text-top" />
                    <div id="brandname">Hola Foodie</div>
                </a>
                <button id="mobile-menu">
                    <img src="../../common img/more.png" alt="" class="menuicon">
                </button>
                <form action="/action.php" id="form">
                    <a href="../../搜尋/index.php">
                        <label for="searchblank" id="search"><img src="../../common img/magnifier.png"
                                id="magnifier"></label>
                        <input type="text" id="searchkey" name="searchblank">
                    </a>
                </form>
            </div>
        </nav>
        <ul class="nav">
            <li class="nav-item">
                <a class="nav-link" href="../../主頁/yanchengtour.php">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../../post/phase2.php">Posts</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">About Us</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../../登入/index.php">Member Area</a>
            </li>
        </ul>
        <div id="mobilenavbar">
            <div class="mobilenav-item">
                <a class="mnav-link" href="../../主頁/yanchengtour.php">Home</a>
            </div>
            <div class="mobilenav-item">
                <a class="mnav-link" href="../../post/phase2.php">Posts</a>
            </div>
            <div class="mobilenav-item">
                <a class="mnav-link" href="#">About Us</a>
            </div>
            <div class="mobilenav-item">
                <a class="mnav-link" href="../../登入/index.php">Member Area</a>
            </div>
        </div>
    </header>
    <div class="Title">
        <div class="content">關於我們</div>
    </div>
    <main>
        <div class="article" id="article">
            <div class="english">Our Story</div>
            <div class="decorate"></div>
            <div class="aboutus">
                在風和日麗的早晨，坐在國文課上發呆的我們，在快被睡神召喚之際，突然！靈感乍現，
                <br>「欸！不如我們來創辦一個美食帳好了！感覺會很好玩！」
                <br>HolaFoodie就此誕生了，也其實就只是一個動機，讓我們持續到了現在。
                <br>把自己的興趣應用到生活上甚至是推廣給周遭的人，
                <br>期望有朝一日，我們能成為大家的美食指標，
                <br>並且能做大做廣，轉而化身為大眾對美食的媒介橋梁，
                <br>用我們的初心與熱忱繼續經營下去...
            </div>
            <div class="photosquare">
                <img src="img/image2.jpg" alt="" class="imageimage1">
                <img src="img/image4.jpg" alt="" class="imageimage2">
                <img src="img/image3.jpg" alt="" class="imageimage2">
            </div>
            <div class="team">
                <div class="teamtitle">我們的團隊</div>
                <div class="teamarticle">
                    <img src="img/weiwei.jpg" alt="" class="photo">
                    <div class="name">
                        <div class="englishname">Wendy</div>
                        <strong>創辦人兼網站規劃師</strong>
                        <div class="decorate1"></div>
                        花點時間思考，那是力量的來源
                        <br>花點時間讀書，那是智慧的基礎
                        <br>花點時間歡笑，那是靈魂的音樂
                        <br>花點時間關心天下事，那能使您胸懷千萬里
                    </div>
                </div>
                <div class="teamarticle">
                    <img src="img/bobo.jpg" alt="" class="photo">
                    <div class="name">
                        <div class="englishname">Kelly</div>
                        <strong>創辦人兼首席文案設計師</strong>
                        <div class="decorate1"></div>
                        有一種態度，叫認真
                        <br>有一種勇敢，叫面對
                        <br>有一種瀟灑，叫坦率
                        <br>期望自已能夠一直抱著這樣的信念勇往直前！
                    </div>
                </div>
                <div class="teamarticle">
                    <img src="img/eric.jpg" alt="" class="photo">
                    <div class="name">
                        <div class="englishname">Eric</div>
                        <strong>大股東兼前端工程師</strong>
                        <div class="decorate1"></div>
                        每一個人都擁有生命，
                        <br>卻不是每個人都能讀懂生命；
                        <br>每一個人都擁有頭腦，
                        <br>卻不是每個人都能善用頭腦。
                    </div>
                </div>
            </div>
        </div>
    </main>
</body>
<footer>
    <div class="footerSquare">
        <a href="#body">
            <div id="back"><i class="fas fa-angle-double-up"></i> Go to Top</div>
        </a>
        <div class="contactus">CONTACT US</div>
        <div id="igiconii">
            <div id="igicondiv">
                <a href="https://www.instagram.com/hola._.foodie/" target="_blank"><img src="../../common img/igicon.png" alt="" class="igicon"></a>
            </div>
        </div>
        <div class="footercontent">
            <p>TEL:07-5252000</p>
            <p>EMAIL:holafoodie@gmail.com</p>
            <p>ADDRESS:No.70,Lianhai Rd, Gushan District, Kaohsiung City,804</p>
            <p>SERVICE HOUR:09:00~17:00</p>
            <p id="copyright">© 2021 Hola.foodie all rights reserved</p>
        </div>
    </div>
</footer>

</html>