<?php
$ourdata = include("config.php");
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $post_id = $_GET['Post_Id'];
  $id = $_SESSION['ID'];
  
  $sql = "INSERT INTO saved VALUES('$id','$post_id')";
  mysqli_query($ourdata, $sql);
  
  echo "收藏成功";
}
?>