create TABLE member(
    ID INT(11) NOT NULL AUTO_INCREMENT,
    email varchar(50) NOT NULL,
    password VARCHAR(50) NOT NULL,
    nickname VARCHAR(10) NOT NULL,
    birthday DATE DEFAULT NULL,
    gender VARCHAR(3) NOT NULL,
    address VARCHAR(50) NOT NULL,
    cellphone VARCHAR(10) NOT NULL,
    level INT(11) NOT NULL DEFAULT '1',
    PRIMARY KEY ( ID ) USING BTREE
);

INSERT INTO member VALUES('1','qwert103044@gmail.com','a34905043','ie0728','2002-07-28','男','高雄市鼓山區馬卡道路408號4樓','0966578333','1');
INSERT INTO member VALUES('2','admin1@gmail.com','a34905043','admin1','2002-01-05','男','彰化縣二林鎮南光里大勇街27號','0920844116','3');
INSERT INTO member VALUES('3','kelly@gmail.com','123456','kelly','2002-02-12','女','高雄市鼓山區蓮海路70號','0912345678','1');
INSERT INTO member VALUES('4','wendy@gmail.com','a34905043','Wendy','2000-08-25','女','高雄市鼓山區蓮海路70號','0912345678','1');