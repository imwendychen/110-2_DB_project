<?php
$ourdata = include("config.php");
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $articleid = $_GET['Post_Id'];
  $id = $_SESSION['ID'];
  $rate = $_POST['rate'];
  
  $sql = "INSERT INTO rate VALUES('$id','$articleid','$rate')";
  mysqli_query($ourdata, $sql);
  
  $check = "SELECT * FROM recommendation WHERE rateuserid ='$id'";
  if (mysqli_num_rows(mysqli_query($ourdata, $check)) == 0) {
    $sql1 = "INSERT INTO recommendation (`rateuserid`,`$articleid`)
    VALUES('$id','$rate')";
    mysqli_query($ourdata, $sql1);
  }else{
    $sql1 = "UPDATE recommendation
    SET `$articleid` = '$rate'
    WHERE rateuserid = '$id' ";
    mysqli_query($ourdata, $sql1);
  }
}
?>
<!DOCTYPE html>
<!-- Coding By CodingNepal - youtube.com/codingnepal -->
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>評分系統</title>
  <link rel="stylesheet" href="style.css">
  <script src="https://kit.fontawesome.com/a076d05399.js"></script>
</head>

<body>
  <form method="POST" action="">
    <div class="wrapper">
      <input type="radio" name="rate" id="star-1" value="1">
      <input type="radio" name="rate" id="star-2" value="2">
      <input type="radio" name="rate" id="star-3" value="3">
      <input type="radio" name="rate" id="star-4" value="4">
      <input type="radio" name="rate" id="star-5" value="5">
      <div class="content">
        <div class="outer">
          <div class="emojis">
            <li class="slideImg"><img src="emojis/emoji-1.png" alt=""></li>
            <li><img src="emojis/emoji-2.png" alt=""></li>
            <li><img src="emojis/emoji-3.png" alt=""></li>
            <li><img src="emojis/emoji-4.png" alt=""></li>
            <li><img src="emojis/emoji-5.png" alt=""></li>
          </div>
        </div>
        <div class="stars">
          <label for="star-1" class="star-1 fas fa-star"></label>
          <label for="star-2" class="star-2 fas fa-star"></label>
          <label for="star-3" class="star-3 fas fa-star"></label>
          <label for="star-4" class="star-4 fas fa-star"></label>
          <label for="star-5" class="star-5 fas fa-star"></label>
        </div>
      </div>
      <div class="footer">
        <span class="text"></span>
        <span class="numb"></span>
      </div>
      <div class="okbutton" style="text-align:center;">
        <button type="submit" class="okbutton">ok!</button>
      </div>
  </form>
  </div>

</body>

</html>