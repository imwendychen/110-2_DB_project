<?php
include("../../登入／config.php");
session_start();
?>
<!DOCTYPE html>
<html>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

<head>
    <title>大港橋</title>
    <!-- 字體 -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=EB+Garamond&family=Noto+Serif+TC:wght@500&family=PT+Serif&family=Vollkorn&display=swap" rel="stylesheet">
    <!-- bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.5/dist/umd/popper.min.js" integrity="sha384-Xe+8cL9oJa6tN/veChSP7q+mnSPaj5Bcu9mPX5F5xIGE0DVittaqT5lorf0EI7Vk" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.min.js" integrity="sha384-kjU+l4N0Yf4ZOJErLsIcvOU2qSb74wXpOhqTvwVx3OElZRweTnQ6d31fXEoRD1Jy" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous" />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <!-- css js -->
    <link href="../../menunav.css" rel="stylesheet" />
    <link rel="stylesheet" href="../rating.css" />
    <link href="bridge.css" rel="stylesheet" />
    <link rel="stylesheet" href="bridge_screen.css" />
    <script src="../../common.js"></script>
    <link rel="icon" type="image/x-icon" href="../../common img/titleicon.png" />
    <!-- font awesome -->
    <script defer src="https://use.fontawesome.com/releases/v5.0.10/js/all.js" integrity="sha384-slN8GvtUJGnv6ca26v8EzVaR9DC58QEwsIk9q1QXdCU8Yu8ck/tL/5szYlBbqmS+" crossorigin="anonymous"></script>
</head>

<body id="body">
    <header>
        <nav class="navbarr navbar-light bg-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="../../主頁/yanchengtour.php">
                    <img src="../../common img/titleicon.png" alt="" width="65" height="65" class="d-inline-block align-text-top" />
                    <div id="brandname">Hola Foodie</div>
                </a>
                <button id="mobile-menu">
                    <img src="../../common img/more.png" alt="" class="menuicon" />
                </button>
                <form action="/action.php" id="form">
                    <a href="../../搜尋/index.php">
                        <label for="searchblank" id="search"><img src="../../common img/magnifier.png" id="magnifier"></label>
                        <input type="text" id="searchkey" name="searchblank">
                    </a>
                </form>
            </div>
        </nav>
        <ul class="nav">
            <li class="nav-item">
                <a class="nav-link" href="../../主頁/yanchengtour.php">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../../post/phase2.php">Posts</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../關於我們/aboutus.php">About Us</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../../登入/index.php">Member Area</a>
            </li>
        </ul>
        <div id="mobilenavbar">
            <div class="mobilenav-item">
                <a class="mnav-link" href="../../主頁/yanchengtour.php">Home</a>
            </div>
            <div class="mobilenav-item">
                <a class="mnav-link" href="../../post/phase2.php">Posts</a>
            </div>
            <div class="mobilenav-item">
                <a class="mnav-link" href="../關於我們/aboutus.php">About Us</a>
            </div>
            <div class="mobilenav-item">
                <a class="mnav-link" href="../../登入/index.php">Member Area</a>
            </div>
        </div>
    </header>
    <div class="Title">
        <div class="content">
            大港橋
            <br />連結兩地的水平旋轉橋，啟航!
        </div>
    </div>
    <main>
        <div class="article" id="article">
            <div class="rating">
                <form method="POST">
                    <a class="rating" href="../評分系統/index.php?Post_Id=25">新增評分</a>
                </form>
            </div>
            <br><br>
            <form method="POST" action="../評分系統/saved.php?Post_Id=25" class="">
                <button><img title="快來收藏文章吧" src="../../common img/save-instagram.png" width="35px"></button>
            </form>
            <div class="articalTitle">
                海洋設計結合商業觀光，並藉由兩者的相輔相成，塑造出愛河在白天與黑夜的優美景色，引人入勝
            </div>

            <div class="lines">
                <span class="line1"></span>
                <span id="font">19th&nbsp;December&nbsp;2021</span>
                <span class="line2"></span>
            </div>
            <div class="imageSquare">
                <img src="img/image2.jpg" alt="" class="topimage" />
                <div class="topcontent">
                    每日下午3點及加開週五週六的晚上7點
                    <br>在大港橋開合秀開始前，會有音樂廣播聲響起，提醒民眾盡快將橋淨空，
                    <br>而在轉動的同時，也會搭配音樂伴奏，使整體更加氣派雄偉。轉動時長大約五分鐘就能完成，
                    <br>讓人難以想像此龐大的建築能如此順暢的移動著...不知不覺就深陷其中~
                </div>
            </div>
            <div class="imageSquare">
                <div class="smalltitle">設計理念</div>
                <div class="decorate"></div>
                <div class="topcontent">
                    大大縮短了駁二藝術特區及蓬萊棧庫群的距離，
                    <br>以往要30分的路程，現在只要短短三分鐘即可往返兩地。
                    <br>大港橋也成為亞洲新灣重要的水岸地圖，其流線與色彩構造的設計，則是參考貝殼及海豚的設計，
                    <br>不僅兼顧第三船渠既有的船舶及遊艇通行，還與美學做了適當的結合，
                    <br>而平時也可供550個人與腳踏車通行，完美體現了實用性的價值所在 !
                </div>
            </div>
            <div class="imageSquare">
                <div class="smalltitle">實地走訪</div>
                <div class="decorate"></div>
                <div class="topcontent">
                    夕陽西下，在河畔休閒漫步的人們正在享受這慵懶的午後，
                    <br>而走在大港橋上的你，往下俯瞰，則是一片汪洋的大海，
                    <br>吹著海風、看著夕陽，心，瞬間平靜了許多。
                    <br>一到了傍晚，那燈光點點的大港橋旁，也時常充斥著飯後散步聊天的情侶、大人及小孩，
                    <br>那種舒服愜意的時刻，在美景的加持下，何不是一個浪漫又平凡的夜晚呢？
                </div>
            </div>
            <div class="time">
                地點 : 高雄市鹽埕區駁二大義站
                <br>
                <br>交通方式 :
                <br>1.輕軌 : 駁二大義站C12，步行1分鐘
                <br>2.捷運 : 鹽埕埔站，步行9分鐘
                <br>3.車 : 停至大港橋停車場，步行6分鐘，需收費
            </div>
            <div class="uber">
                <a href="https://reurl.cc/VDNN0N" target="_blank"><img src="../../common img/uber.png" id="bookingimg" alt="" width="60" height="60" /></a>
                <a href="../../booking/booking/booking.html" target="_blank"><img src="../../common img/booking.png" id="bookingimg" alt="" width="60" height="60" /></a>
            </div>
        </div>
    </main>
    <footer>
        <div class="footerSquare">
            <a href="#body">
                <div id="back"><i class="fas fa-angle-double-up"></i> Go to Top</div>
            </a>
            <div class="contactus">CONTACT US</div>
            <div id="igiconii">
                <div id="igicondiv">
                    <a href="https://www.instagram.com/hola._.foodie/" target="_blank"><img src="../../common img/igicon.png" alt="" class="igicon" /></a>
                </div>
            </div>
            <div class="footercontent">
                <p>TEL:07-5252000</p>
                <p>EMAIL:holafoodie@gmail.com</p>
                <p>ADDRESS:No.70,Lianhai Rd, Gushan District, Kaohsiung City,804</p>
                <p>SERVICE HOUR:09:00~17:00</p>
                <p id="copyright">© 2021 Hola.foodie all rights reserved</p>
            </div>
        </div>
    </footer>
</body>

</html>